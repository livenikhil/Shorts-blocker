# Study Focus Blocker (Android prototype)

A native Kotlin Android prototype that attempts to leave likely YouTube Shorts and Instagram Reels screens using an Accessibility Service, while keeping ordinary YouTube videos usable.

## Important limitations

- This is an **early best-effort prototype**, not a guaranteed permanent blocker.
- YouTube/Instagram can change view IDs and accessibility labels; detection may stop working after app updates.
- Some Instagram versions do not expose enough information for reliable Reel detection. Some false positives or missed screens are possible.
- The detector uses accessibility view IDs and on-device visible text. It does not upload screen content.
- It uses Android's Back action to leave a detected screen. Depending on the app version, this may go back to a previous screen rather than a dedicated block page.
- The app cannot prevent a user from disabling its Accessibility Service, force-stopping it, uninstalling it, or using another app/device.
- Accessibility permission is powerful. This prototype is not intended to secretly monitor users. Enable it only if you understand and consent to the permission.
- This is not yet a Play Store-ready release. A public release requires policy review, privacy disclosures, testing, and clear accessibility-permission disclosures.

## Build in Android Studio

1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync. If prompted, install missing SDK components.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally created at:
   `app/build/outputs/apk/debug/app-debug.apk`

No APK is included in this source archive because it has not been built or tested in an Android SDK environment.

## Install and enable

1. Install the debug APK on your test phone.
2. Open **Study Focus Blocker**.
3. Tap **Open Accessibility Settings**.
4. Select **Study Focus Blocker** and enable the service after reviewing the disclosure.
5. Return to the app and verify the service status says enabled.
6. Test an ordinary YouTube video first; it should remain usable.
7. Open a YouTube Short and an Instagram Reel. Check whether the app returns to the previous screen.
8. If the app does not detect a target, record the Android version, YouTube/Instagram app version, and what screen was open. Detection rules may need adjustment.

## Project contents

- `MainActivity.kt`: simple settings/dashboard UI.
- `BlockerAccessibilityService.kt`: local best-effort screen detection and Back action.
- `BlockerPrefs.kt`: preferences.
- `blocker_accessibility_config.xml`: Accessibility Service configuration.

## Current test checklist

- [ ] Service can be enabled and status updates.
- [ ] Protection master switch works.
- [ ] YouTube Shorts switch works.
- [ ] Instagram Reels switch works.
- [ ] Ordinary YouTube video playback is not interrupted.
- [ ] YouTube Shorts are detected on the installed version.
- [ ] Instagram Reels are detected on the installed version.
- [ ] App survives returning to home and reopening.
- [ ] Reboot behavior is checked.
