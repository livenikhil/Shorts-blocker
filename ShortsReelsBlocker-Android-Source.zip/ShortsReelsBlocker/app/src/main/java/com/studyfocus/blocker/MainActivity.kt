package com.studyfocus.blocker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(BlockerPrefs.FILE, Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var youtubeSwitch: Switch
    private lateinit var instagramSwitch: Switch
    private lateinit var masterSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(246, 248, 252)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "Study Focus"
            textSize = 30f
            setTextColor(Color.rgb(22, 34, 61))
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title)
        page.addView(TextView(this).apply {
            text = "Shorts & Reels Blocker"
            textSize = 16f
            setTextColor(Color.rgb(75, 91, 120))
            setPadding(0, dp(4), 0, dp(18))
        })

        val hero = card()
        hero.addView(TextView(this).apply {
            text = "📚  Take back your focus"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(25, 43, 78))
        })
        hero.addView(TextView(this).apply {
            text = "When a likely Shorts or Reels screen is detected, the app presses Back to leave it. Regular YouTube videos should remain usable."
            textSize = 14f
            setTextColor(Color.rgb(72, 84, 106))
            setPadding(0, dp(8), 0, dp(8))
        })
        page.addView(hero, matchWrap())

        val controls = card()
        controls.addView(sectionTitle("Blocking controls"))
        masterSwitch = addSwitch(controls, "Protection enabled", "Turn detection on or off", BlockerPrefs.MASTER, true)
        youtubeSwitch = addSwitch(controls, "Block YouTube Shorts", "Keep standard YouTube videos available", BlockerPrefs.YOUTUBE, true)
        instagramSwitch = addSwitch(controls, "Block Instagram Reels", "Other Instagram screens may still work", BlockerPrefs.INSTAGRAM, true)
        page.addView(controls, matchWrap())

        val permissions = card()
        permissions.addView(sectionTitle("Required setup"))
        permissions.addView(TextView(this).apply {
            text = "Android requires you to enable the accessibility service manually. Detection runs on your phone; this prototype does not send screen text to a server."
            textSize = 14f
            setTextColor(Color.rgb(72, 84, 106))
        })
        val enable = Button(this).apply {
            text = "Open Accessibility Settings"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        permissions.addView(enable, matchWrap(top = 12))
        page.addView(permissions, matchWrap())

        val statusCard = card()
        statusCard.addView(sectionTitle("Service status"))
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(38, 55, 85))
        }
        statusCard.addView(status)
        val refresh = Button(this).apply {
            text = "Refresh status"
            isAllCaps = false
            setOnClickListener { refreshStatus() }
        }
        statusCard.addView(refresh, matchWrap(top = 8))
        page.addView(statusCard, matchWrap())

        val note = TextView(this).apply {
            text = "Important: This is an early test build. YouTube and Instagram can change their screen layouts, so detection may miss some screens or occasionally block the wrong screen. Test before relying on it for study sessions."
            textSize = 12f
            setTextColor(Color.rgb(105, 113, 130))
            setPadding(dp(4), dp(14), dp(4), 0)
        }
        page.addView(note)
        refreshStatus()
    }

    private fun addSwitch(parent: LinearLayout, label: String, subtitle: String, key: String, default: Boolean): Switch {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val sw = Switch(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.rgb(28, 42, 68))
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                refreshStatus()
            }
        }
        wrap.addView(sw)
        wrap.addView(TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(Color.rgb(100, 110, 130))
            setPadding(0, 0, dp(4), 0)
        })
        parent.addView(wrap, matchWrap())
        return sw
    }

    private fun refreshStatus() {
        val enabled = isAccessibilityServiceEnabled()
        status.text = if (enabled) {
            "● Accessibility service is enabled\nProtection: ${if (prefs.getBoolean(BlockerPrefs.MASTER, true)) "ON" else "OFF"}"
        } else {
            "○ Accessibility service is not enabled\nTap “Open Accessibility Settings” and enable Study Focus Blocker."
        }
        status.setTextColor(if (enabled) Color.rgb(20, 125, 80) else Color.rgb(180, 90, 30))
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${BlockerAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(Color.WHITE)
        elevation = dp(2).toFloat()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(14)
        layoutParams = lp
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(22, 34, 61))
        setPadding(0, 0, 0, dp(8))
    }

    private fun matchWrap(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (top > 0) topMargin = dp(top)
            bottomMargin = dp(14)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
