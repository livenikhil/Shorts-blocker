package com.studyfocus.blocker

object BlockerPrefs {
    const val FILE = "study_focus_preferences"
    const val MASTER = "protection_enabled"
    const val YOUTUBE = "block_youtube_shorts"
    const val INSTAGRAM = "block_instagram_reels"
}
