package com.studyfocus.blocker

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Early best-effort detector.
 *
 * Uses stable-ish resource-id hints first. Text-only matching is deliberately
 * conservative because the word "Shorts" can appear in YouTube navigation
 * while a normal video is playing.
 */
class BlockerAccessibilityService : AccessibilityService() {
    private var lastBackAt = 0L
    private val cooldownMs = 1800L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(BlockerPrefs.FILE, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(BlockerPrefs.MASTER, true)) return

        val pkg = event.packageName?.toString() ?: return
        val isYouTube = pkg == "com.google.android.youtube" &&
                prefs.getBoolean(BlockerPrefs.YOUTUBE, true)
        val isInstagram = pkg == "com.instagram.android" &&
                prefs.getBoolean(BlockerPrefs.INSTAGRAM, true)
        if (!isYouTube && !isInstagram) return

        val root = rootInActiveWindow ?: return
        val detected = try {
            if (isYouTube) looksLikeYouTubeShort(root) else looksLikeInstagramReel(root)
        } finally {
            root.recycle()
        }

        if (detected) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastBackAt >= cooldownMs) {
                lastBackAt = now
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    private fun looksLikeYouTubeShort(root: AccessibilityNodeInfo): Boolean {
        val ids = collectIds(root, 0, 700).map { it.lowercase(Locale.ROOT) }
        val strongIdHints = listOf(
            "shorts_player", "shorts_view_pager", "shorts_container",
            "shorts_video", "reel_watch_player", "shorts_view"
        )
        if (ids.any { id -> strongIdHints.any(id::contains) }) return true

        // Conservative fallback: require multiple Shorts-specific accessibility clues.
        val text = collectText(root, 0, 700).joinToString(" ").lowercase(Locale.ROOT)
        val hasShortsLabel = text.contains("shorts") || text.contains("short video")
        val hasShortControls = listOf("remix", "use this sound", "sound", "comments", "share")
            .count { text.contains(it) } >= 3
        return hasShortsLabel && hasShortControls
    }

    private fun looksLikeInstagramReel(root: AccessibilityNodeInfo): Boolean {
        val ids = collectIds(root, 0, 700).map { it.lowercase(Locale.ROOT) }
        val strongIdHints = listOf(
            "reel_viewer", "reels_viewer", "reel_player", "reels_video",
            "clips_viewer", "clips_video", "reel_feed"
        )
        if (ids.any { id -> strongIdHints.any(id::contains) }) return true

        // Instagram's UI labels vary by version and language. Require several clues.
        val text = collectText(root, 0, 700).joinToString(" ").lowercase(Locale.ROOT)
        val actionClues = listOf("like", "comment", "share", "audio", "follow")
            .count { text.contains(it) } >= 4
        val reelClue = text.contains("original audio") ||
                text.contains("view insights") ||
                text.contains("remix") ||
                text.contains("reels")
        return reelClue && actionClues
    }

    private fun collectIds(node: AccessibilityNodeInfo?, depth: Int, budget: Int): List<String> {
        if (node == null || depth > 28 || budget <= 0) return emptyList()
        val result = ArrayList<String>()
        node.viewIdResourceName?.let { result.add(it) }
        val count = minOf(node.childCount, budget)
        for (i in 0 until count) {
            val child = node.getChild(i) ?: continue
            result.addAll(collectIds(child, depth + 1, budget - i - 1))
            child.recycle()
            if (result.size >= budget) break
        }
        return result
    }

    private fun collectText(node: AccessibilityNodeInfo?, depth: Int, budget: Int): List<String> {
        if (node == null || depth > 28 || budget <= 0) return emptyList()
        val result = ArrayList<String>()
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { result.add(it) }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { result.add(it) }
        val count = minOf(node.childCount, budget)
        for (i in 0 until count) {
            val child = node.getChild(i) ?: continue
            result.addAll(collectText(child, depth + 1, budget - i - 1))
            child.recycle()
            if (result.size >= budget) break
        }
        return result
    }

    override fun onInterrupt() = Unit
}
